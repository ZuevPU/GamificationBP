import os
import datetime
import gspread
from dotenv import load_dotenv
from google.oauth2.service_account import Credentials

# Загрузка .env файла
load_dotenv()

# Подключение к Google Sheets
SHEET_ID = os.getenv("GOOGLE_SHEET_ID")
SERVICE_ACCOUNT_FILE = os.getenv("GOOGLE_CREDENTIALS")  # путь к JSON-файлу

scope = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]

creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=scope)
gc = gspread.authorize(creds)
sh = gc.open_by_key(SHEET_ID)

users_ws = sh.worksheet("Users")
log_ws = sh.worksheet("PointsLog")
keywords_ws = sh.worksheet("Keywords")
bonuses_ws = sh.worksheet("Bonuses")

def add_new_user(user_id, username):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    users_ws.append_row([user_id, username, 0, now])

def get_user_data(user_id):
    cell = users_ws.find(str(user_id))
    row = users_ws.row_values(cell.row)
    name = row[1]
    points = int(row[2])

    # Прогресс
    target = 20

    # История
    logs = log_ws.get_all_records()
    history = [
        {"text": f"+{log['Баллы']} за {log['Тип']} ({log['Дата']})"}
        for log in logs if str(log['UserID']) == str(user_id)
    ]

    # Бонусы
    all_bonuses = bonuses_ws.get_all_records()
    bonuses = []
    for b in all_bonuses:
        available = points >= int(b['Порог'])
        text = b['Содержание'] if available else f"🔒 {b['Содержание']}"
        bonuses.append({"text": text, "available": available})

    return {
        "id": user_id,
        "name": name,
        "points": points,
        "progress": {"current": points, "target": target},
        "history": history,
        "bonuses": bonuses
    }


def submit_keyword(user_id, keyword):
    keywords = get_keywords_with_points()
    keyword = keyword.lower()
    if keyword not in keywords:
        return False

    points = keywords[keyword]

    # Обновляем баллы
    cell = users_ws.find(str(user_id))
    row_idx = cell.row
    current_points = int(users_ws.cell(row_idx, 3).value)
    new_points = current_points + points
    users_ws.update_cell(row_idx, 3, new_points)
    users_ws.update_cell(row_idx, 4, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    # Логируем
    log_ws.append_row([
        user_id,
        "задание",
        points,
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ])

    return True


def get_keywords_with_points():
    rows = keywords_ws.get_all_records()
    return {row['Кодовое слово'].lower(): int(row['Баллы']) for row in rows}
