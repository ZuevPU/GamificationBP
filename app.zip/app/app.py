from flask import Flask, request, jsonify
from gsheet import get_user_data, add_new_user

app = Flask(__name__)

@app.route('/api/submit_user', methods=['POST'])
def submit_user():
    data = request.get_json()
    user_id = str(data.get("user_id"))
    username = data.get("username", "Без имени")

    user = get_user_data(user_id)

    if user["points"] == 0 and user["name"] == "Неизвестный":
        add_new_user(user_id, username)
        user = get_user_data(user_id)

    return jsonify(user)
